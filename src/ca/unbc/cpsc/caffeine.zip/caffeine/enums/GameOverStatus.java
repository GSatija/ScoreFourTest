package ca.unbc.cpsc.caffeine.enums;

public enum GameOverStatus {

    LOSS, DRAW, WIN;

}
