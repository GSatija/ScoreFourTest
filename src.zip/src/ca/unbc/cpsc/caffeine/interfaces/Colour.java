package ca.unbc.cpsc.caffeine.interfaces;

public interface Colour {

    public abstract boolean isBlack();
    public abstract boolean isWhite();

}

